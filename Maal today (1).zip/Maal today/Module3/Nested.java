import java.util.*;
import java.io.*;
public class Nested{
public static void main(String args[]){
try{
int arr[]={1, 2, 3, 4, 5};
System.out.println("Enter index of the array you want to access: ");
Scanner sc = new Scanner(System.in);
int i = sc.nextInt();
System.out.println("The element is: " + arr[i]);
try{
System.out.println("Enter the value of Divisor");
int b = sc.nextInt();
int x = arr[i]/b;
System.out.println("The answer is: "+x);
}
catch(ArithmeticException e2){
System.out.println("Division by zero in not possible");
}
}
catch(ArrayIndexOutOfBoundsException e1){
System.out.println("Element at such index does not exist");
}
finally{
System.out.println("Name:Kaushik Roll number: 22BCP357");
}
}
}