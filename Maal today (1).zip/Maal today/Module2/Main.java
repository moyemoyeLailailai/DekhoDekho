public class Main{

public static void main(String[] args){
System.out.println()
Dist d1= new Dist();
d1.getdetails();
d1.display();
Dist d2 = new Dist();
d2.getdetails();
d2.display();
d1.adder(d2);
 }
}