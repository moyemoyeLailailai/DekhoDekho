public class Test {
    public static void main(String[] args) {
        System.out.println("Kaushik Jain 22BCP357");
        System.out.println("Inside Parent class from package1");
        System.out.println("Inside Child class in the same package (package1)");
        System.out.println("Inside Child class in a different package (package2)");
    }
}
