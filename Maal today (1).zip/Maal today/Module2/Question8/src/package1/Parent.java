package package1;

public class Parent {
    protected void display() {
        System.out.println("Inside Parent class from package1");
    }
}
