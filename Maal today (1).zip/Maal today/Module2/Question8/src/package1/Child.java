package package1;

public class Child extends Parent {
    public void display() {
        System.out.println("Inside Child class in the same package (package1)");
    }
}
