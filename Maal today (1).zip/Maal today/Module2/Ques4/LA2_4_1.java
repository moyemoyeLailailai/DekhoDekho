public class LA2_4_1 {
    public static void main(String[] args) {
System.out.println("Kaushik Jain 22BCP357");
        int x = 10;
        updateValue(x);
        System.out.println("Value of x: " + x);
    }

    public static void updateValue(int a) {
        a = 20;
    }
}
