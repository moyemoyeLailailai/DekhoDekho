public class LA2_4_3 {
    public static void main(String[] args) {
System.out.println("Kaushik Jain 22BCP357");
        int sum = calculateSum(5, 6);
        System.out.println("Sum: " + sum);
    }

    public static int calculateSum(int a, int b) {
        return a + b;
    }
}
