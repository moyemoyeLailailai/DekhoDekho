public class La4{

public static void main(String[] args){
 
}

public void add(int x, int y){
int z= x+y;
System.out.println("Add result:"+z);
}} 
