import java.util.*;
class importexport{

public static void main(String args[]){

Scanner k= new Scanner(System.in);
int a,b,c;

System.out.println("enter the first integer");
int m =k.nextInt();
System.out.println("value is:"+m);
System.out.println("enter the 2nd integer");
int n =k.nextInt();
System.out.println("value is:"+n);
System.out.println("Sum is"+(m+n));

 }
}