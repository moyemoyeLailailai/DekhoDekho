public class Cla{

public static void main(String args[]){

System.out.println("1st cla:"+ args[0]);
System.out.println("2nd cla:"+ args[1]);
  }

}