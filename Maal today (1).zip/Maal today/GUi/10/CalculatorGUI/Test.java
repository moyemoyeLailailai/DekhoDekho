import java.awt.*;
import javax.swing.*;

public class Test
{
	public static void main(String args[])
	{
		GUICalc g=new GUICalc();
	}
}